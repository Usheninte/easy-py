def songWriters():
    writer1, writer2 = "Kendrick Lamar - as Writer", "Mike Will Made It - as Writer"
    print("Song Writers >>")
    print(writer1)
    print(writer2)


# Function call
songWriters()


def musicLabels():
    musicLabel1, musicLabel2, musicLabel3 = "Top Dawg", "Aftermath", "Interscope"
    print("Music Labels >>")
    print(musicLabel1)
    print(musicLabel2)
    print(musicLabel3)


# Function call
musicLabels()


def releaseHistory():
    firstReleaseWorldwide = "March 30, 2017"
    firstReleaseUSA = "April 4, 2017"
    print("Release History >>")
    print(firstReleaseWorldwide)
    print(firstReleaseUSA)


# Function call
releaseHistory()


def certifiedPlatinum():
    print("Certified Platinum >>")
    return True


# Save function to variable
plat = certifiedPlatinum()
print(plat)
